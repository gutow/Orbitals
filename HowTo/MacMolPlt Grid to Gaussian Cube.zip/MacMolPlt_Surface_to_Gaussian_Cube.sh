# execute the java -jar command
java -jar MacMolPlt_Surface_to_Gaussian_Cube.jar