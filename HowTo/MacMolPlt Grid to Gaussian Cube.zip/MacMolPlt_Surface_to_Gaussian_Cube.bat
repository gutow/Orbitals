@echo off
rem Set GRID_TO_CUBE_HOME to the Orbitals to Web installation directory.
rem
if "%GRID_TO_CUBE_HOME%x"=="x" set GRID_TO_CUBE_HOME="."
java -jar "%GRID_TO_CUBE_HOME%\MacMolPlt_Surface_to_Gaussian_Cube.jar"