//
// MacMolPlt_Surface_to_Gaussian_Cube.java
// 
//This program allows the user to select a bunch of MacMolPlt surface (grid) files
//and have them converted to gzipped Gaussian Cube files with the extensions .cube.gz added.
//
//  Created by Jonathan Gutow on 6/7/06.
//  May be redistributed and modified under the GNU Public License.
//


import java.util.*;
import java.util.zip.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.datatransfer.*;
import java.awt.dnd.*;
import javax.swing.*;
import javax.swing.filechooser.*;


public class MacMolPlt_Surface_to_Gaussian_Cube extends JPanel
implements ActionListener {
	
	static private final String newline = "\n";
    JButton OrbopenButton, OrbdeleteButton, CooropenButton, saveButton;
    JTextArea log;
	JTextField Coorfile, appletPath;
    JFileChooser fc;
	ArrayListTransferHandler arrayListHandler;
	JList OrbFileList, OrbFilenameList;
	
    public MacMolPlt_Surface_to_Gaussian_Cube() {
        super(new BorderLayout());
		
        //Create the log first, because the action listeners
        //need to refer to it.
        log = new JTextArea(9,20);
        log.setMargin(new Insets(5,5,5,5));
        log.setEditable(false);
        JScrollPane logScrollPane = new JScrollPane(log);
				
		//Create a label for the log
		JLabel logLabel = new JLabel("Log and Error Messages:");
		//put in its own panel so that it will be centered
		JPanel logLabelPanel = new JPanel();
		logLabelPanel.add(logLabel);
		
		//Create a panel of the log and its label
		JPanel logPanel = new JPanel();
		logPanel.setLayout(new BorderLayout());
		logPanel.add(logLabelPanel, BorderLayout.CENTER);
		logPanel.add(logScrollPane, BorderLayout.PAGE_END);
		
        //Create file chooser
        fc = new JFileChooser();
		
		//Create the file and filename lists and list view to handle the list of 
		//orbital files.
		arrayListHandler = new ArrayListTransferHandler();
		DefaultListModel orbfilelist = new DefaultListModel();
		DefaultListModel orbnamelist = new DefaultListModel();
		OrbFileList = new JList(orbfilelist);
		OrbFileList.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        OrbFileList.setTransferHandler(arrayListHandler);
		OrbFilenameList = new JList(orbnamelist);
		OrbFilenameList.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        OrbFilenameList.setTransferHandler(arrayListHandler);		
        OrbFilenameList.setDragEnabled(false);
        JScrollPane OrbListView = new JScrollPane(OrbFilenameList);
        OrbListView.setPreferredSize(new Dimension(300, 200));
        
		//Create the label for the orbital file area
		JLabel OrbLabel = new JLabel("Orbital Files:");
		
        //Create the orbital file add button.
        OrbopenButton = new JButton("Add File(s)...");
        OrbopenButton.addActionListener(this);
		
		//Create the delete file button
		OrbdeleteButton = new JButton("Delete Selected");
		OrbdeleteButton.addActionListener(this);
		
        //Create the save button. 
        saveButton = new JButton("Save all as .cube.gz ...");
        saveButton.addActionListener(this);
		
        //For layout purposes, put things in separate panels
		//Orbital file selection
		JPanel OrbButtonsPanel = new JPanel();
		OrbButtonsPanel.add(OrbopenButton);
		OrbButtonsPanel.add(OrbdeleteButton);
		
		//Title and border for the orbital file selection
		JPanel OrbPanel = new JPanel();
		OrbPanel.setLayout(new BorderLayout());
		OrbPanel.add(OrbButtonsPanel, BorderLayout.PAGE_START);
		OrbPanel.add(OrbListView, BorderLayout.PAGE_END);
    	OrbPanel.setBorder(BorderFactory.createTitledBorder("Orbital Files:"));
		
		//save file selection
		JPanel savePanel = new JPanel();
		savePanel.add(saveButton);
		
        //Add the buttons and the log to this panel.
        add(logPanel, BorderLayout.PAGE_START);
		add(OrbPanel, BorderLayout.LINE_END);
		add(savePanel, BorderLayout.PAGE_END);
    }
	
    public void actionPerformed(ActionEvent e) {
		
        //Handle open button action.
        if (e.getSource() == OrbopenButton) {
			//enable this to allow multiple file selection
			fc.setMultiSelectionEnabled(true);
			fc.setDialogTitle("Choose the Orbital Files:");
            int returnVal = fc.showOpenDialog(MacMolPlt_Surface_to_Gaussian_Cube.this);			
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                File[] files = fc.getSelectedFiles();
				DefaultListModel filelistModel = (DefaultListModel)OrbFileList.getModel();
				DefaultListModel filenamelistModel = (DefaultListModel)OrbFilenameList.getModel();
                //We will open the files later.
				//Now we're just making a list of filenames to display.
				//Also will keep a parallel list of files so we can access them.
				for (int i = 0; i < files.length; i++){
					//					log.append("Orbital file "+i+": " + files[i].getName() + "." + newline);
					filelistModel.addElement(files[i]);
					String str = files[i].getName();
					filenamelistModel.addElement(str);
				}
				log.append("Actual file list is now:\n"+filelistModel+newline); 
            } else {
                log.append("Orbital file selection cancelled by user." + newline);
            }
            log.setCaretPosition(log.getDocument().getLength());
			//Handle Delete button
		} else if (e.getSource() == OrbdeleteButton){
			DefaultListModel filelistModel = (DefaultListModel)OrbFileList.getModel();
			DefaultListModel filenamelistModel = (DefaultListModel)OrbFilenameList.getModel();
			//find out which are selected and remove them.
			int[] todelete = OrbFilenameList.getSelectedIndices();
			for (int i = 0; i<todelete.length; i++) {
				filelistModel.remove(todelete[i]);
				filenamelistModel.remove(todelete[i]);
			}
			log.append("Actual file list is now:\n"+filelistModel+newline);
			log.setCaretPosition(log.getDocument().getLength());
			//Handle save button action.
        } else if (e.getSource() == saveButton) {
			DefaultListModel filelistModel = (DefaultListModel)OrbFileList.getModel();
			DefaultListModel filenamelistModel = (DefaultListModel)OrbFilenameList.getModel();
			//This is where the call to the translate and save routine goes.
			log.append("Saving files..."+newline);
            log.setCaretPosition(log.getDocument().getLength());
			//Loop through the file list.
			for (int i = 0; i<filenamelistModel.getSize(); i++){
				//Open each.
				log.append("Working on:  "+filenamelistModel.getElementAt(i)+"."+newline);
				log.setCaretPosition(log.getDocument().getLength());
				//Translate it and write a gzipped .cube.
				File tempfile = (File)filelistModel.getElementAt(i); //This will give us a way to access the file.
				//open a fileReader
				String line1str="";
				String line2str="";
				String line3str="";
				String line4str="";
				String addcommentstr="";
				BufferedReader infile =null;
				try{
					infile =new BufferedReader(new FileReader(tempfile));
					line1str = infile.readLine();
					log.append("Line 1 of file: "+line1str + newline);
					addcommentstr = "File modified from MacMolPlt grid file to Gaussian .cube by MacMolPlt_Surface_to_Gaussian_Cube.java.";
					line2str = infile.readLine();
					log.append("Line 2 of file: "+line2str + newline);
					line3str = infile.readLine();
					log.append("Line 3 of file: "+line3str + newline);
					line4str = infile.readLine();
					log.append("Line 4 of file: "+line4str + newline);
					log.setCaretPosition(log.getDocument().getLength());
				} catch (IOException IOe){
					log.append ("IOException while reading file..will skip this file."+newline);
					log.append(IOe.getMessage()+newline);

				}
				//Parse the lines to get number of points in x,y and z
				String Separator = " ";
				String[] ngridpoints = line2str.split(Separator);
				String[] origin = line3str.split(Separator);
				String[] gridincr = line4str.split(Separator);
				float[] originfloat = {0,0,0};
				float[] gridincrfloat = {0,0,0};
				//It appears that the file uses strange units for the lengths even though everything
				//else is in Angstroms by default.  Need to convert these to numbers, multiply by
				//1.88973.  This works with MacMolPlt version 5.6.  I may need a flag...Unfortunately,
				//there is no way to tell from the grid file.
				float scalefactor = Float.valueOf("1.88973").floatValue();
				for (int j = 0; j <3;j++){ //this is to convert and check
					originfloat[j] = Float.valueOf(origin[j]).floatValue();//make into number
					originfloat[j]=originfloat[j]*scalefactor;//multiply it
					origin[j] = Float.toString(originfloat[j]);//put back in the string
					gridincrfloat[j] = Float.valueOf(gridincr[j]).floatValue();
					gridincrfloat[j]=gridincrfloat[j]*scalefactor;//multiply it
					gridincr[j] = Float.toString(gridincrfloat[j]);//put back in the string
					log.append("ngridpoints["+j+"] = "+ngridpoints[j]+newline);
					log.append("origin["+j+"] = " +origin[j]+newline);
					log.append("gridincr["+j+"] = "+gridincr[j]+newline);
				}
				//Now begin building the new file
				//Create the new file with the appropriate extensions
				String filestring = tempfile.toString();
				int strIndex = filestring.lastIndexOf(".");
				if (strIndex != -1) {
					filestring = filestring.substring(0, strIndex); //remove the last extension 
				}
				File outfile = new File(filestring+".cube.gz");
				//It is going to be gzipped
				PrintStream out= null;
				try {
					out = new PrintStream(new GZIPOutputStream(new FileOutputStream(outfile)));
				} catch (IOException IOe){
					log.append(IOe.getMessage()+newline);
				}
				out.println(line1str); //copy the first comment line
				out.println(addcommentstr);//add second comment line explaining file origin
				//add the number of atoms and the origin of the grid
				out.println("0 "+origin[0]+" "+origin[1]+" "+origin[2]);
				//npoints xincr yincr zincr
				out.println(ngridpoints[0]+" "+gridincr[0]+" 0.000000 0.000000"); //along x axis
				out.println(ngridpoints[1]+" 0.000000 "+gridincr[1]+" 0.000000"); //along y axis
				out.println(ngridpoints[2]+" 0.000000 0.000000 "+gridincr[2]); //along z axis
				//the rest of the file is exactly the same as the MacMolPlt grid file.
				try{
					String str = "";
					while((str = infile.readLine()) != null){
						out.println(str);
					}
				} catch (IOException IOe){
					log.append(IOe.getMessage()+newline);
				}
				out.close();
			}
        }
    }
	
    /**
		* Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private static void createAndShowGUI() {
        //Make sure we have nice window decorations.
        JFrame.setDefaultLookAndFeelDecorated(true);
        JDialog.setDefaultLookAndFeelDecorated(true);
		
        //Create and set up the window.
        JFrame frame = new JFrame("Orbitals to Web");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
        //Create and set up the content pane.
        JComponent newContentPane = new MacMolPlt_Surface_to_Gaussian_Cube();
        newContentPane.setOpaque(true); //content panes must be opaque
        frame.setContentPane(newContentPane);
		
        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }
	
    public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }
	
}
