@echo off
rem Set ORBITALS_TO_WEB_HOME to the Orbitals to Web installation directory.
rem
if "%ORBITALS_TO_WEB_HOME%x"=="x" set ORBITALS_TO_WEB_HOME="."
java -jar "%ORBITALS_TO_WEB_HOME%\Orbitals_to_Web.jar"