//
//  JmolPage.java
//  Orbitals to Web
//
//  Created by Jonathan Gutow on 5/28/06.
//  May be redistributed and modified under the GNU Public License.
//
import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.datatransfer.*;
import java.awt.dnd.*;
import javax.swing.*;
import javax.swing.filechooser.*;
import java.text.*;


public class JmolPage {
	//set some constants for page formats.
	public static final int OneOrb = 1; 
	public static final int TwoOrb =2; 
	public static final int ThreeOrb=3; 
	public static final int FourOrb =4;
	public static final int WideOneOrb =5; //not yet implemented
	public static final int WideTwoOrb =6;	 //not yet implemented
	public static final int MoleculesFromLinks = 7; //not yet implemented (for a different program or class?)
	public static final int MoleculesFromMenu = 8; //not yet implemented (for a different program or class?)
	public static final int Vibrations = 9; //not yet implemented (for a different program or class?)
	
	//set some constants for the molecule or atom rendering mode
	public static final int SmallAtomDot = 1;
	public static final int Wireframe = 2;
	
	
	private boolean checkformat(int FormatChoice) throws IOException {
		//Error checking for allowed format choices. Returns true if OK.
		switch (FormatChoice) {
			case 1: //Allow displaying one orbital at a time
				return true;
			case 2: //Allow displaying up to two orbitals at a time
				return true;
			case 3: //Allow displaying up to three orbitals at a time
				return true;
			case 4: //Allow displaying up to four orbitals at a time
				return true;
			case 5: //Allow displaying one orbital at a time on a wide display
				throw new IOException("WideOneOrb format not yet implemented.");
			case 6://Allow displaying up to two orbitals at a time on a wide display
				throw new IOException("WideTwoOrb format not yet implemented.");
			case 7: //Allow a display to choose molecules from links on a page
				throw new IOException("MoleculesFromLinks format not yet implemented.");
			case 8: //Allow molecules to be chosen from a menu list
				throw new IOException("MoleculesFromMenu format not yet implemented.");
			case 9: //Allows a molecule to be loaded along with a menu of vibrations to animate
				throw new IOException("Vibrations format not yet implemented.");
			default: //we should not get here so return error
				throw new IOException("Unacceptable format choice for web page.");
		}
	}
	
	public boolean orbtohtml(int FormatChoice, int Rendering, File outfile, String Coorfile, JList OrbList, String appletPath) 
	 throws IOException { //returns true if successful.
		 boolean formatOK = false;
		 try {
			 formatOK = checkformat(FormatChoice); 
		 }catch (IOException IOe) {
			 throw IOe;
		 }
		//If we get here things should be OK, but just in case check the formatOK boolean
		 if (formatOK) {
			 //open the printstream for outfile
			 PrintStream out = null;
			 try {
				 out = new PrintStream(outfile);
			 } catch (FileNotFoundException e){
				 throw e; //Pass the error up the line so it can go in the log window.
			 }
			 //html output.
			     out.println ("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
    			 out.println ("<html>");
    			 out.println ("<head>");
    			 out.println ("  <meta content=\"text/html; charset=ISO-8859-1\"");
    			 out.println (" http-equiv=\"content-type\">");
    			 out.println ("  <title>Sufaces using jmol</title>");
    			 out.println ("  <meta content=\"???\" name=\"author\">");
    			 out.println ("  <meta content=\"chemistry, orbital, orbitals, isosurface, wavefunction, Jmol, image, animation, rotatable, live display\" name=\"keywords\">");
    			 out.println ("  <meta content=\"Orbital display using jmol\" name=\"description\">");
    			 out.println ("  <meta");
    			 out.println (" content=\"Page design and layout by J. Gutow 5-2006, page written by Orbitals to Web.jar\"");
    			 out.println (" name=\"details\">");
    			 out.println ("  <meta");
    			 out.println (" content=\"This page is designed to have the text and normal html edited in a standard web design\"");
    			 out.println (" name=\"instr1\">");
    			 out.println ("  <meta");
    			 out.println (" content=\"program.  The javascript is to control the jmol applet (see below).  It is best to use\"");
    			 out.println (" name=\"instr2\">");
    			 out.println ("  <meta");
    			 out.println (" content=\"the java program to generate the proper java script to allow orbital display.  It is\"");
    			 out.println (" name=\"instr3\">");
    			 out.println ("  <meta");
    			 out.println (" content=\"important to have all the gzipped files in the same directory as the .html file.  The\"");
    			 out.println (" name=\"instr4\">");
    			 out.println ("  <meta");
    			 out.println (" content=\"files needed are: 1) a gzipped file with the atom coordinates, in any of the formats Jmol\"");
    			 out.println (" name=\"instr5\">");
    			 out.println ("  <meta");
    			 out.println (" content=\"can read. 2) a gzipped gaussian cube file for each of the orbitals to be displayed.  To\"");
    			 out.println (" name=\"instr6\">");
    			 out.println ("  <meta");
    			 out.println (" content=\"save loading time it seems to be better to avoid including the atom coordinates in the\"");
    			 out.println (" name=\"instr7\">");
    			 out.println ("  <meta");
    			 out.println (" content=\"cube files.  It is also recommended that the file names for the surfaces correspond to\"");
    			 out.println (" name=\"instr8\">");
    			 out.println ("  <meta");
    			 out.println (" content=\"reasonable names for the orbitals as the file names are used to generate the menu items\"");
    			 out.println (" name=\"instr9\">");
    			 out.println ("  <meta content=\"that appear in the popup menus for selecting orbitals.\"");
    			 out.println (" name=\"instr10\">");
    			 out.println ("  <meta");
    			 out.println (" content=\"The relative path to Jmol on your server must be correct below!!\"");
    			 out.println (" name=\"instr11\">");
    			 out.println ("  <script src=\""+appletPath+"/Jmol.js\"></script>");
    			 out.println ("</head>");
    			 out.println ("<body>");
    			 out.println ("<div style=\"text-align: center;\"><big><big><span");
    			 out.println (" style=\"font-weight: bold;\">&lt;Replace this text with your title&gt;<br>");
    			 out.println ("</span></big></big>");
    			 out.println ("<div style=\"text-align: left;\"><big><big><span");
    			 out.println (" style=\"font-weight: bold;\"></span></big></big>&lt;Describe your");
    			 out.println ("molecule and orbitals here. Don't forget to mention that there is a");
    			 out.println ("live display below.&nbsp; The user's browser window may be too small to");
    			 out.println ("display your text and the table containing the Jmol applet without");
    			 out.println ("scrolling.&gt;<br>");
    			 out.println ("<br>");
    			 out.println ("<big><big><span style=\"font-weight: bold;\"></span></big></big>");
    			 out.println ("<table style=\"width: 100%; text-align: left;\" border=\"1\" cellpadding=\"2\"");
    			 out.println (" cellspacing=\"2\">");
    			 out.println ("  <tbody>");
    			 out.println ("    <tr>");
    			 out.println ("      <td style=\"vertical-align: top;\">");
    			 out.println ("      <script>");
    			 out.println ("jmolInitialize(\""+appletPath+"\");");
				 //System.out.println (Rendering);
				 //should have been able to use a case statement below, but it didn't work reliably.
				 switch (Rendering){
					   case SmallAtomDot: {
					 //Appropriate for displaying orbitals on one atom
						   out.println ("jmolApplet(300, \"load " + Coorfile +"; spacefill 2%; background white\"); ");
						   break;
				 }
					   case Wireframe: {
					 //Appropriate for displaying orbitals on a molecule
						 out.println ("jmolApplet(300, \"load " + Coorfile +"; spacefill 0%; wireframe; labels %e; set labeloffset 0 0; background white\"); ");
						 break;
					 }
				 }
    			 out.println ("jmolBr();");
    			 out.println ("jmolHtml(\"This image may be rotated and zoomed.  See below for more instructions.\");");
    			 out.println ("        </script>");
    			 out.println ("      <br>");
    			 out.println ("      </td>");
    			 out.println ("      <td style=\"vertical-align: top;\">");
    			 out.println ("      <div style=\"text-align: right;\"> </div>");
    			 out.println ("      <form>");
    			 out.println ("        <div style=\"text-align: right;\"> </div>");
    			 out.println ("        <table style=\"width: 100%; text-align: left;\" border=\"0\"");
    			 out.println (" cellpadding=\"2\" cellspacing=\"2\">");
    			 out.println ("          <tbody>");
				 //Now loop for the number of simultaneous orbitals
				 //Define an array of strings which will be used to set the select radio button for the color
				 String poscolor = "";
				 String negcolor ="";
				 String color1 ="";
				 String color2 = "";
				 String color3 = "";
				 String color4 = "";
				 for (int j = 1; j <= FormatChoice; j++){
					 //colors for the initial display
					 switch (j) {
						 case 1:{
							 negcolor ="red";
							 poscolor = "blue";
							 color1 = "'true'";
							 color2 = " ";
							 color3 = " ";
							 color4 = " ";
//							 System.out.println(j+": executing case 1");
							 break;
						 }
						 case 2:{
							 negcolor ="yellow";
							 poscolor = "green";
							 color1 = " ";
							 color2 = "'true'";
							 color3 = " ";
							 color4 = " ";
//							 System.out.println(j+": executing case 2");
							 break;
						 }
						 case 3:{
							 negcolor ="cyan";
							 poscolor = "purple";
							 color1 = " ";
							 color2 = " ";
							 color3 = "'true'";
							 color4 = " ";
//							 System.out.println(j+": executing case 3");
							 break;
						 }
						 case 4: {
							 negcolor ="pink";
							 poscolor = "brown";
							 color1 = " ";
							 color2 = " ";
							 color3 = " ";
							 color4 = "'true'";
//							 System.out.println(j+": executing case 4");
							 break;
						 }
						 default:{
							 System.out.println(j+": executing default");
							 break;
						 }
					 }
					 out.println ("            <tr>");
					 out.println ("              <td colspan=\"1\" rowspan=\"1\"");
					 out.println (" style=\"vertical-align: top; white-space: nowrap; text-align: right;\"><span");
					 out.println (" style=\"font-weight: bold;\">Orbital");
					 out.println (j+":</span><br>");
					 out.println ("              </td>");
					 out.println ("              <td style=\"vertical-align: top;\">");
					 out.println ("              <script>");
					 out.println ("		jmolMenu([");
					 out.println ("		['isosurface neg"+j+" delete; isosurface pos"+j+" delete;','none'],");
					 //Loop the following line to make an entry for each orbital.
					 for (int i=0; i < OrbList.getModel().getSize(); i++){
						 int dotIndex = OrbList.getModel().getElementAt(i).toString().indexOf(".");
						 String Itemname = OrbList.getModel().getElementAt(i).toString().substring(0,dotIndex);
						 out.println ("		['isosurface neg"+j+" delete; isosurface pos"+j+" delete; isosurface neg"+j+" -0.06 \""+OrbList.getModel().getElementAt(i)+"\"; color isosurface "+negcolor+";isosurface pos"+j+" 0.06 \""+OrbList.getModel().getElementAt(i)+"\";color isosurface "+poscolor+";',\""+Itemname+"\"],");
					 }
					 out.println ("		]);");
					 out.println ("		</script>");
					 out.println ("              <br>");
					 out.println ("              </td>");
					 out.println ("            </tr>");
					 out.println ("            <tr>");
					 out.println ("              <td");
					 out.println (" style=\"vertical-align: top; text-align: right; white-space: nowrap;\">Surface");
					 out.println ("Type:<br>");
					 out.println ("              </td>");
					 out.println ("              <td");
					 out.println (" style=\"vertical-align: top; text-align: left; white-space: nowrap;\">");
					 out.println ("              <script>");
					 out.println ("		jmolRadioGroup([['isosurface neg"+j+" fill nomesh nodots; isosurface pos"+j+" fill nomesh nodots;','Solid','true'],");
					 out.println ("		['isosurface neg"+j+" mesh nofill nodots; isosurface pos"+j+" mesh nofill nodots;', 'Mesh'],");
					 out.println ("		['isosurface neg"+j+" dots nomesh nofill; isosurface pos"+j+" dots nomesh nofill;', 'Dot']");
					 out.println ("		 ]);");
					 out.println ("		</script><br>");
					 out.println ("              </td>");
					 out.println ("            </tr>");
					 out.println ("            <tr>");
					 out.println ("              <td");
					 out.println (" style=\"vertical-align: top; text-align: right; white-space: nowrap;\">Surface");
					 out.println ("Color:<br>");
					 out.println ("              </td>");
					 out.println ("              <td");
					 out.println (" style=\"vertical-align: top; text-align: left; white-space: nowrap;\">");
					 out.println ("              <script>");
					 out.println ("		jmolRadioGroup([['isosurface neg"+j+"; color isosurface red; isosurface pos"+j+"; color isosurface blue;',\"blue/red\","+color1+"],");
					 out.println ("		['isosurface neg"+j+"; color isosurface yellow; isosurface pos"+j+"; color isosurface green;',\"green/yellow\","+color2+"],");
					 out.println ("		['isosurface neg"+j+"; color isosurface cyan; isosurface pos"+j+"; color isosurface purple;',\"purple/cyan\","+color3+"],");
					 out.println ("		['isosurface neg"+j+"; color isosurface pink; isosurface pos"+j+"; color isosurface brown;',\"brown/pink\","+color4+"]");
					 out.println ("		]);");
					 out.println ("		</script>");
					 out.println ("              <br>");
					 out.println ("              </td>");
					 out.println ("            </tr>");
					 
				 }
				 out.println ("          </tbody>");
    			 out.println ("        </table>");
    			 out.println ("      </form>");
				 out.println ("&lt;This space can be used as a short caption for the applet at left.&gt;<br><br>");
    			 out.println ("      <small><a href=\"http://www.java.com\">Javascript</a>");
				 Date now = new Date();
				 String now_string = DateFormat.getDateInstance().format(now);//Specify medium verbosity on the date and time
    			 out.println ("generated by a java program (<a href=\"http://www.uwosh.edu/faculty_staff/gutow/Orbitals/HowTo/using_orbtohtml_pl.html\">Orbitals to Web</a>) on "+now_string+". </small><small><br>");
    			 out.println ("Original");
    			 out.println ("page composed by <a href=\"http://www.uwosh.edu/faculty_staff/gutow/\">J.");
    			 out.println ("Gutow 4/2006</a>. </small> </td>");
    			 out.println ("    </tr>");
    			 out.println ("    <tr>");
    			 out.println ("      <td colspan=\"2\" rowspan=\"1\" style=\"vertical-align: top;\">");
    			 out.println ("      <div style=\"text-align: center;\"><span style=\"font-weight: bold;\">Instructions");
    			 out.println ("for using Jmol to display");
    			 out.println ("orbitals</span>: <br>");
    			 out.println ("      </div>");
    			 out.println ("      <ol>");
    			 out.println ("        <li>Choose which orbitals to display by selecting them using the");
    			 out.println ("orbital popup menus.&nbsp; You can control orbital color and fill mode");
    			 out.println ("by selecting the appropriate options following each orbital menu.&nbsp;");
    			 out.println ("        </li>");
    			 out.println ("        <li>ROTATE the image by");
    			 out.println ("holding");
    			 out.println ("down the mouse button while moving the cursor over the image.&nbsp; </li>");
    			 out.println ("        <li>ZOOM by holding down the shift key while moving the cursor");
    			 out.println ("up");
    			 out.println ("(decrease magnification) or down (increase magnification) on top of the");
    			 out.println ("image.&nbsp; </li>");
    			 out.println ("        <li>Other options are available in the control menu accessible by");
    			 out.println ("holding");
    			 out.println ("the mouse button down while the cursor is over \"Jmol\" in the lower");
    			 out.println ("right corner (right click also works on a multibutton mouse).&nbsp; </li>");
    			 out.println ("        <li>For more info about Jmol go to <a target=\"_blank\"");
    			 out.println (" href=\"http://www.jmol.org\">www.jmol.org.</a></li>");
    			 out.println ("      </ol>");
    			 out.println ("      </td>");
    			 out.println ("    </tr>");
    			 out.println ("  </tbody>");
    			 out.println ("</table>");
    			 out.println ("</div>");
    			 out.println ("</div>");
    			 out.println ("</body>");
    			 out.println ("</html>");
			 out.close();
		 }
		 return true;
	}
	
}
