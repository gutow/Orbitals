//
//  Orbitals_to_Web.java
//  Orbitals to Web
//
//  Created by Jonathan Gutow on 6/7/06.
//  May be redistributed and modified under the GNU Public License.
//
// Things that ought to be adjustable parameters or added:
// 1) boxes to input x,y,z rotation of loaded molecule, since often not good in file.
// 2) level at which surfaces are drawn (use spinner?)--recommend 0.1 - 0.02
// 3) Help button (need to make html help page and then put it in package)
// 4) tabs for molecules or vibrations, which will have different preferences to adjust.

import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.datatransfer.*;
import java.awt.dnd.*;
import javax.swing.*;
import javax.swing.filechooser.*;


public class Orbitals_to_Web extends JPanel
implements ActionListener {

	static private final String newline = "\n";
    JButton OrbopenButton, OrbdeleteButton, CooropenButton, saveButton;
    JTextArea log;
	JTextField Coorfile, appletPath;
    JFileChooser fc;
	ArrayListTransferHandler arrayListHandler;
	JList OrbList;
	JComboBox RenderMode, FormatBox;
	
    public Orbitals_to_Web() {
        super(new BorderLayout());
		
        //Create the log first, because the action listeners
        //need to refer to it.
        log = new JTextArea(9,20);
        log.setMargin(new Insets(5,5,5,5));
        log.setEditable(false);
        JScrollPane logScrollPane = new JScrollPane(log);
		
		//Create the Coordinate file text
		Coorfile = new JTextField(20);
		Coorfile.addActionListener(this);
		Coorfile.setText("");
		
		//Create a label for the log
		JLabel logLabel = new JLabel("Log and Error Messages:");
		//put in its own panel so that it will be centered
		JPanel logLabelPanel = new JPanel();
		logLabelPanel.add(logLabel);
		
		//Create the ComboBox (popup menu) for the Rendering Mode
		JLabel RenderModeLabel = new JLabel("Rendering Mode:");
		String[] RenderModes = { "Small Atom Dot", "Wireframe"};
		RenderMode = new JComboBox(RenderModes);
		RenderMode.setSelectedIndex(0);
		//Attached no action listener.  Will just read for selection.
		//Put in panel with label
		JPanel RenderPanel = new JPanel();
		RenderPanel.add(RenderModeLabel);
		RenderPanel.add(RenderMode);
		
		//Create the ComboBox (popup menu) for the Page Format
		JLabel PageFormatLabel = new JLabel("Page Format:");
		String[] PageFormats = {
			"Single orbital",
			"Up to 2 orbitals at once",
			"Up to 3 orbitals at once",
			"Up to 4 orbitals at once",
//			"One orbital, wide display",
//			"Two orbitals, wide display",
//			"Molecules from menu, no orbitals",
//			"Vibrations"
		};
		FormatBox = new JComboBox(PageFormats);
		FormatBox.setSelectedIndex(3);
		//Put in panel with a label
		JPanel FormatPanel = new JPanel();
		FormatPanel.add(PageFormatLabel);
		FormatPanel.add(FormatBox);
		
		//Combine the comboboxes into a panel for formating
		JPanel RenderFormatPanel = new JPanel();
		RenderFormatPanel.setLayout(new BorderLayout());
		RenderFormatPanel.add(RenderPanel, BorderLayout.PAGE_START);
		RenderFormatPanel.add(FormatPanel, BorderLayout.PAGE_END);
		
		//Create a panel of the log and its label
		JPanel logPanel = new JPanel();
		logPanel.setLayout(new BorderLayout());
		logPanel.add(RenderFormatPanel, BorderLayout.PAGE_START);
		logPanel.add(logLabelPanel, BorderLayout.CENTER);
		logPanel.add(logScrollPane, BorderLayout.PAGE_END);
		
		//Create the text field for the path to the JMol applet
		appletPath = new JTextField(20);
		appletPath.addActionListener(this);
		appletPath.setText("../../Applets/Java/Jmol");
				
        //Create file chooser
        fc = new JFileChooser();
		
		//Create the list and list view to handle the list of 
		//orbital files.
		arrayListHandler = new ArrayListTransferHandler();
		DefaultListModel orbfilelist = new DefaultListModel();
		OrbList = new JList(orbfilelist);
		OrbList.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        OrbList.setTransferHandler(arrayListHandler);
        OrbList.setDragEnabled(true);
        JScrollPane OrbListView = new JScrollPane(OrbList);
        OrbListView.setPreferredSize(new Dimension(300, 200));
        
		//Create the label for the orbital file area
		JLabel OrbLabel = new JLabel("Orbital Files (Drag to Preferred Order):");
		
        //Create the orbital file add button.
        OrbopenButton = new JButton("Add File(s)...");
        OrbopenButton.addActionListener(this);
		
		//Create the delete file button
		OrbdeleteButton = new JButton("Delete Selected");
		OrbdeleteButton.addActionListener(this);
		
		//Create the coordinate file open button.
		CooropenButton = new JButton("Select Coordinate File...");
        CooropenButton.addActionListener(this);

        //Create the save button. 
        saveButton = new JButton("Save .html as...");
        saveButton.addActionListener(this);
		
        //For layout purposes, put things in separate panels
        //Coordinate file selection
		JLabel CoorLabel = new JLabel("File containing atom coordinates:");
		JPanel CoorPanel = new JPanel(); //use FlowLayout
		CoorPanel.add(CoorLabel);
        CoorPanel.add(Coorfile);
		CoorPanel.add(CooropenButton);
 
		//Orbital file selection
		JPanel OrbButtonsPanel = new JPanel();
		OrbButtonsPanel.add(OrbopenButton);
		OrbButtonsPanel.add(OrbdeleteButton);
		
		//Title and border for the orbital file selection
		JPanel OrbPanel = new JPanel();
		OrbPanel.setLayout(new BorderLayout());
		OrbPanel.add(OrbButtonsPanel, BorderLayout.PAGE_START);
		OrbPanel.add(OrbListView, BorderLayout.PAGE_END);
    	OrbPanel.setBorder(BorderFactory.createTitledBorder("Orbital Files (Drag to Preferred Order):"));
		
		//save file selection
		JPanel savePanel = new JPanel();
		savePanel.add(saveButton);
		
		//Path to applet
		JPanel pathPanel = new JPanel(); //use default flow layout
		JLabel pathLabel = new JLabel("Relative Path to Jmol Applet:");
		pathPanel.add(pathLabel);
		pathPanel.add(appletPath);
		
		//Path and coordinate file grouped
		JPanel PathandCoor = new JPanel();
		PathandCoor.setLayout(new BorderLayout());
		PathandCoor.add(pathPanel, BorderLayout.PAGE_START);
		PathandCoor.add(CoorPanel, BorderLayout.PAGE_END);
		
        //Add the buttons and the log to this panel.
        add(PathandCoor, BorderLayout.PAGE_START);
        add(logPanel, BorderLayout.CENTER);
		add(OrbPanel, BorderLayout.LINE_END);
		add(savePanel, BorderLayout.PAGE_END);
    }
	
    public void actionPerformed(ActionEvent e) {
		
        //Handle open button action.
        if (e.getSource() == OrbopenButton) {
			//enable this to allow multiple file selection
			fc.setMultiSelectionEnabled(true);
			fc.setDialogTitle("Choose the Orbital Files:");
            int returnVal = fc.showOpenDialog(Orbitals_to_Web.this);			
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                File[] files = fc.getSelectedFiles();
				DefaultListModel listModel = (DefaultListModel)OrbList.getModel();
                //This is where a real application would open the file.
				//Were're just making a list since we only use the file names.
				for (int i = 0; i < files.length; i++){
//					log.append("Orbital file "+i+": " + files[i].getName() + "." + newline);
					String str = files[i].getName();
					listModel.addElement(str);
				}
                
            } else {
                log.append("Orbital file selection cancelled by user." + newline);
            }
            log.setCaretPosition(log.getDocument().getLength());
		//Handle Delete button
		} else if (e.getSource() == OrbdeleteButton){
			DefaultListModel listModel = (DefaultListModel)OrbList.getModel();
			//find out which are selected and remove them.
			int[] todelete = OrbList.getSelectedIndices();
			for (int i = 0; i<todelete.length; i++) {
				listModel.remove(todelete[i]);
			}
			//Handle save button action.
        } else if (e.getSource() == saveButton) {
			fc.setDialogTitle("Save .html file as:");
            int returnVal = fc.showSaveDialog(Orbitals_to_Web.this);
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                File file = fc.getSelectedFile();
                //This is where a real application would save the file.
				DefaultListModel listModel = (DefaultListModel)OrbList.getModel();
               log.append("Saving: " + file.getName() + "." + newline);
			   //Let's make sure we can get out the file names.
			   log.append("  Coordinate file: " + Coorfile.getText() + "." + newline);
			   for (int i = 0; i < listModel.getSize(); i++) {
				   log.append("  Orbital file #" + i + " is " + listModel.getElementAt(i) + "." + newline);
			   }
			   String str = Coorfile.getText();
			   JmolPage WebPage = new JmolPage();
			   boolean retVal = true;
			   try {
				   retVal = WebPage.orbtohtml((FormatBox.getSelectedIndex()+1), (RenderMode.getSelectedIndex()+1), file, str, OrbList, appletPath.getText());
			   }catch (IOException IOe) {
				   log.append (IOe.getMessage());
			   }
			  if (!retVal) {
				   log.append("Call to orbtohtml unsuccessful.");
			   }
            } else {
                log.append("Save command cancelled by \"user\"." + newline);
            }
            log.setCaretPosition(log.getDocument().getLength());
			//Handle choose Coordinate file button
        }else if (e.getSource() == CooropenButton) {
			//make sure they can only select one file
			fc.setMultiSelectionEnabled(false);
			fc.setDialogTitle("Choose a Coordinate File:");
            int returnVal = fc.showOpenDialog(Orbitals_to_Web.this);
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                File file = fc.getSelectedFile();
                //This is where a real application would open the file.
				Coorfile.removeAll();
				String str = file.getName();
				Coorfile.setText(str);
//				log.append("Coordinate file: " + file.getName() + "." + newline);
            } else {
                log.append("Coordinate file selection cancelled by user." + newline);
            }
            log.setCaretPosition(log.getDocument().getLength());
			
        }
    }
	
    /**
		* Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private static void createAndShowGUI() {
        //Make sure we have nice window decorations.
        JFrame.setDefaultLookAndFeelDecorated(true);
        JDialog.setDefaultLookAndFeelDecorated(true);
		
        //Create and set up the window.
        JFrame frame = new JFrame("Orbitals to Web");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
        //Create and set up the content pane.
        JComponent newContentPane = new Orbitals_to_Web();
        newContentPane.setOpaque(true); //content panes must be opaque
        frame.setContentPane(newContentPane);
		
        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }
	
    public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }
	
}
