//
//  JmolPage.java
//  Orbitals to Web
//
//  Created by Jonathan Gutow on 5/28/06.
//  May be redistributed and modified under the GNU Public License.
//
import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.datatransfer.*;
import java.awt.dnd.*;
import javax.swing.*;
import javax.swing.filechooser.*;

public class orbtohtmlscript {
//set some constants for page formats.
		final int OneOrb = 1;
		final int TwoOrb =2;
		final int ThreeOrb=3;
		final int FourOrb =4;
		final int WideOneOrb =5;
		final int WideTwoOrb =6;
	
	public static boolean orbtohtmlscript(int FormatChoice, String Coorfile, JList OrbList) { //returns true if successful.
		switch (FormatChoice) {
			case 1:
				System.out.println("OneOrb format not yet implemented.");
				return false;
			case 2:
				System.out.println("TwoOrb format not yet implemented.");
				return false;
			case 3:
				System.out.println("Three Orb format not yet implemented.");
				return false;
			case 4: //for now we will run an external perl script.  Eventually the code should be converted
				//to Java.
				//need to find the script and call it.  I've included it in the .Jar file.
				//Start with a call to getResource.  Do I need a subroutine?
				java.net.URL scriptURL = Orbitals_to_Web.class.getResource("orbtohtmlscript.class");
				System.out.println("The script URL is: " + scriptURL + ".");
				//I will need to extract the script from the Jar file to use it!?
				//I think it may be easier to translate the perl into java!
				//Once have found script in Jar run the script using Runtime.getRuntime().exec(command)
				//see http://javaalmanac.com/egs/java.lang/Exec.html?l=new
				//will need to attach the file list to the command line.
				return true;
			case 5:
				System.out.println("WideOneOrb format not yet implemented.");
				return false;
			case 6:
				System.out.println("WideTwoOrb format not yet implemented.");
				return false;
			default: //we should not get here so return error
				System.out.println("Unacceptable format for web page in routine orbtohtmlscript.");
				return false;
		}
		
	}

}
