# execute the java -jar command
java -jar Orbitals_to_Web.jar